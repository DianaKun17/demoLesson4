package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class HelloController {

    @FXML
    private Button button;

    @FXML
    private TextArea chatArea;

    @FXML
    private TextField textField;

    @FXML
    void pushMessage(ActionEvent event) {

        String message = textField.getText().trim();
        if (message.length() != 0) {
            chatArea.setText(message);
        }
    }

}

